var daka = require("./lib/wps");
exports.main_handler = async () => {
  daka();
};
